let arr1 = [
  {
    id: 1,
    name: "shehzad",
  },
  {
    id: 2,
    name: "asad",
  },
  {
    id: 3,
    name: "ajmal",
  },
];

let arr2 = [];

let arr3 = [];

module.exports = { arr1, arr2, arr3 };